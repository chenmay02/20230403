let numLayers = 5; //圖形層數
let colors = [[226, 42, 87], [148, 0, 211]]; //漸層顏色，從紅到紫

let points = [
  [1-10,3-10], [3-10,4-10], [8-10,5-10],[9-10,7-10],[9-10,15-10],[10-10,19-10],[11-10,22-10],[13-10,23-10],
  [15-10,24-10],[13-10,24-10],[13-10,22-10],[13-10,19-10], [15-10,15-10], [16-10,12-10],[17-10,7-10],
  [18-10,5-10],[22-10,4-10],[25-10,3-10],[22-10,2-10],[17-10,1-10],[9-10,1-10],[3-10,2-10],[1-10,3-10]
];

function setup() {
  createCanvas(windowWidth, windowHeight );
  
    // textSize(30+mouseX/20); // 設定文字大小
    // fill("#415a77")
    // text("Hello World", -5,150); // 繪製文字
    
  // 調整 points 內的值，放大圖形
  for (let i = 0; i < points.length; i++) {
    for (let j = 0; j < points[i].length; j++) {
      points[i][j] = points[i][j] * 20;
    }
  }
}

function draw() {
  background(255);
  // 設定畫布座標系統為中央點為原點
  translate(width/2, height/2);
  scale(1, -1); //上下翻轉

  let scaleVal = map(mouseX, 0, width, 0.5, 2); // 根據滑鼠X座標的位置計算縮放比例
  scale(scaleVal); // 縮放畫布

  for (let i = 0; i < numLayers; i++) {
    let c = lerpColor(color(colors[0]), color(colors[1]), i / (numLayers - 1)); //計算當前層的顏色
    stroke(c);
    strokeWeight(numLayers - i); //根據層數設定線條粗細
    for (let j = 0; j < points.length - 1; j++) {
      line(points[j][0], points[j][1] - i * 10, points[j+1][0], points[j+1][1] - i * 10); //根據層數調整線條高度
    }
    line(points[points.length - 1][0], points[points.length - 1][1] - i * 10, points[0][0], points[0][1] - i * 10); //根據層數調整線條高度

    pop(); // 回復先前的矩陣狀態

    // 在第一層時加上文字
    if (i === 0) {
      push(); // 儲存當前的矩陣狀態
      scale(1, -1); //上下翻轉
      textSize(32);
      textAlign(CENTER, CENTER);
      fill(0, 102, 153);
      noStroke();
      text("歡迎來到霍格華茲!", 0, -100);
      pop(); // 回復先前的矩陣狀態
  }
}
}
